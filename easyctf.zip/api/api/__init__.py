import api.annotations
import api.auth
import api.cache
import api.common
import api.findteam
import api.group
import api.password_recovery
import api.problem
import api.programming
import api.schemas
import api.scoreboard
import api.stats
import api.team
import api.updates
import api.user

import api.config