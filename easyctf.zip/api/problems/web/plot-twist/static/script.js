console.log('no one would EVER think to look in the console! flag backup: easyctf{remember_to_check_everywhere}');
//because console.logging right?