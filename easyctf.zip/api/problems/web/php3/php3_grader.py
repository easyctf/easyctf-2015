def grade(tid, answer):
	if answer.find("wh3n_will_my_php_n1ghtmar3s_enddddd?!") != -1:
		return { "correct": True, "message": "They will never end." }
	return { "correct": False, "message": "Nope, try again!" }