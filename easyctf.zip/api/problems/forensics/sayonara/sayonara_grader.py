def grade(tid, answer):
	if answer.find("do_a_frustration") != -1:
		return { "correct": True, "message": "Now all nation can be win." }
	return { "correct": False, "message": "when we practice or try hard, dream will be come true. dont left dream as dream" }