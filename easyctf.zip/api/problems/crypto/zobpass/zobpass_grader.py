def grade(tid, answer):
	if answer.find("sH0r+_m3554g3") != -1:
		return { "correct": True, "message": "Good job!" }
	return { "correct": False, "message": "Nope. Try again." }