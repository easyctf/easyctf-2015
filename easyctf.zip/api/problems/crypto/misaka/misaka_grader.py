def grade(tid, answer):
	if answer.lower().find("l3v3l5esp3rs") != -1:
		return { "correct": True, "message": "kudos" }
	return { "correct": False, "message": "Misaka is the best, though chaosagent disagrees. He likes Accelerator" }