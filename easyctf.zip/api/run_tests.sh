#!/bin/bash

test_path="./tests"

if [[ -n "$1" ]]; then
  test_path=$1
fi

python3 -b -m pytest --showlocals -s -v "$test_path"
