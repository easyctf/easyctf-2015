<?php

$pass = "xxxXXX_u'll never_guess th1s_passw0rd_biches_XXXxxX";
$flag = "easyctf{never_trust_strcmp}";

?>