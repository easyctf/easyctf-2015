<?php
	highlight_file("index.php");
?>