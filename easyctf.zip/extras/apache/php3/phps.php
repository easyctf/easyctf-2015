<?php
	highlight_file(substr($_SERVER['REQUEST_URI'],1));
?>