<?php

$email = "php3@easyctf.com";
$password = "xxxXXX_u'll never_guess th1s_passw0rd_topkek_XXXxxX";
$flag = "easyctf{wh3n_will_my_php_n1ghtmar3s_enddddd?!}";

?>