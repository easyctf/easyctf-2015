<?php
	mysql_connect("localhost", "wastebin3", "ipgwnbnpqwriompsomdgpunpas9t8*(Shet08a(EH804w869yq");
	@mysql_select_db("wastebin3") or die("can't select database");
	$flag = "easyctf{54771309-67e5-4704-8743-6981a40b}";
?>